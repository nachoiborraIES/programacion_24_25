﻿/*
 * Interfaz implementada por todos los elementos domóticos
 * que pueden encenderse/apagarse
 */
interface IEncendible
{
    void Encender();
    void Apagar();
    bool Consultar();
}