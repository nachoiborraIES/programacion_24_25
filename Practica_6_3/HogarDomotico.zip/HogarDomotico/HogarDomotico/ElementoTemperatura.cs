﻿/*
 * Elemento domótico con temperatura
 */
abstract class ElementoTemperatura : ElementoDomotico, IEncendible
{
    protected bool encendido;
    protected int temperatura;

    public ElementoTemperatura(string nombre) : base(nombre)
    {
        this.encendido = false;
        this.temperatura = 0;
    }

    public void Encender()
    {
        this.encendido = true;
    }

    public void Apagar()
    {
        this.encendido = false;
    }

    public bool Consultar()
    {
        return encendido;
    }

    public override void Mostrar()
    {
        if (encendido)
        {
            Console.BackgroundColor = ConsoleColor.Green;
            Console.Write(" ");
        }
        else
        {
            Console.BackgroundColor = ConsoleColor.Red;
            Console.Write(" ");
        }
        Console.ResetColor();
        Console.Write(" " + nombre + " (" + temperatura + "ºC)");
    }
}