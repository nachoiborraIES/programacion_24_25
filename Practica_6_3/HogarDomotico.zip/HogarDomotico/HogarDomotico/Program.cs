﻿/*
 * Programa principal que gestiona y muestra por pantalla el conjunto de
 * elementos domóticos de un hogar
 */
using System;

class Ejercicio
{
    static void Menu()
    {
        Console.SetCursorPosition(0, 10);
        Console.WriteLine(new string('-', Console.WindowWidth));
        Console.Write("A/B Abrir/Cerrar Pta. Princ | ");
        Console.WriteLine("C/D Abrir/Cerrar Pta. Garaje");
        Console.Write("E/F On/Off Luz Salón | ");
        Console.WriteLine("G/H On/Off Luz Cocina");
        Console.Write("I/J On/Off Horno | ");
        Console.WriteLine("K/L Subir/Bajar Horno");
        Console.Write("M/N On/Off Calefaccion | ");
        Console.WriteLine("O/P Subir/Bajar Calefaccion");
        Console.Write("Q. Apagar Todo | ");
        Console.WriteLine("S. Salir");
    }

    static void GestionarOpcion(GestorDomotico gd, ConsoleKeyInfo tecla)
    {
        Puerta p;
        Luz l;
        Horno h;
        Calefaccion c;

        switch (tecla.Key)
        {
            case ConsoleKey.A:
                p = (Puerta)gd.GetElemento(0);
                p.Abrir();
                break;
            case ConsoleKey.B:
                p = (Puerta)gd.GetElemento(0);
                p.Cerrar();
                break;
            case ConsoleKey.C:
                p = (Puerta)gd.GetElemento(1);
                p.Abrir();
                break;
            case ConsoleKey.D:
                p = (Puerta)gd.GetElemento(1);
                p.Cerrar();
                break;
            case ConsoleKey.E:
                l = (Luz)gd.GetElemento(2);
                l.Encender();
                break;
            case ConsoleKey.F:
                l = (Luz)gd.GetElemento(2);
                l.Apagar();
                break;
            case ConsoleKey.G:
                l = (Luz)gd.GetElemento(3);
                l.Encender();
                break;
            case ConsoleKey.H:
                l = (Luz)gd.GetElemento(3);
                l.Apagar();
                break;
            case ConsoleKey.I:
                h = (Horno)gd.GetElemento(4);
                h.Encender();
                break;
            case ConsoleKey.J:
                h = (Horno)gd.GetElemento(4);
                h.Apagar();
                break;
            case ConsoleKey.K:
                h = (Horno)gd.GetElemento(4);
                h.Temperatura++;
                break;
            case ConsoleKey.L:
                h = (Horno)gd.GetElemento(4);
                h.Temperatura--;
                break;
            case ConsoleKey.M:
                c = (Calefaccion)gd.GetElemento(5);
                c.Encender();
                break;
            case ConsoleKey.N:
                c = (Calefaccion)gd.GetElemento(5);
                c.Apagar();
                break;
            case ConsoleKey.O:
                c = (Calefaccion)gd.GetElemento(5);
                c.Temperatura++;
                break;
            case ConsoleKey.P:
                c = (Calefaccion)gd.GetElemento(5);
                c.Temperatura--;
                break;
            case ConsoleKey.Q:
                gd.ApagarTodo();
                break;
        }
    }

    static void Main()
    {
        ConsoleKeyInfo tecla;
        GestorDomotico gd = new GestorDomotico();
        gd.MostrarEstado();
        Menu();
        do
        {
            tecla = Console.ReadKey(true);
            GestionarOpcion(gd, tecla);
            gd.MostrarEstado();
        }
        while (tecla.Key != ConsoleKey.S);
    }
}