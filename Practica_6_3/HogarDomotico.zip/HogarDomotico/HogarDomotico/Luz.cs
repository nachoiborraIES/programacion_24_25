﻿/*
 * Elemento domótico de tipo luz
 */
class Luz: ElementoDomotico, IEncendible
{
    private bool encendido;

    public Luz(string nombre) : base(nombre)
    {
        this.encendido = false;
    }

    public void Encender()
    {
        this.encendido = true;
    }

    public void Apagar()
    {
        this.encendido = false;
    }

    public bool Consultar()
    {
        return encendido;
    }

    public override void Mostrar()
    {
        if (encendido)
        {
            Console.BackgroundColor = ConsoleColor.Green;
            Console.Write(" ");
        }
        else
        {
            Console.BackgroundColor = ConsoleColor.Red;
            Console.Write(" ");
        }
        Console.ResetColor();
        Console.Write(" " + nombre);
    }
}