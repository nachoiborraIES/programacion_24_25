﻿/*
 * Elemento domótico de tipo horno
 */
class Horno: ElementoTemperatura
{
    public int Temperatura
    {
        get { return temperatura; }

        set
        {
            if (value >= 0 && value <= 250)
            {
                temperatura = value;
            }
        }
    }
    public Horno(string nombre): base(nombre)
    {
    }
}