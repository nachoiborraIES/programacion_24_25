﻿/*Parte principal del programa desde donde gestionarmos el menú*/

class Program
{
    enum opciones { NUEVA = 1,CERRAR,VER,TOTAL,SALIR}
    static void Main()
    {
        List<Reforma> reformas = new List<Reforma>();
        opciones op;

        do
        {
            op = Menu();

            switch (op)
            {
                case opciones.NUEVA:
                    NuevaReforma(reformas);
                    break;

                case opciones.CERRAR:
                    CerrarReforma(reformas);
                    break;

                case opciones.VER:
                    VerReforma(reformas);
                    break;

                case opciones.TOTAL:
                    TotalReformas(reformas);
                    break;
            }
        }
        while (op != opciones.SALIR);
    }

    static opciones Menu()
    {
        opciones op;

        Console.WriteLine("Menú de gestión de reformas: ");
        Console.WriteLine("1. Nueva reforma");
        Console.WriteLine("2. Cerrar reforma");
        Console.WriteLine("3. Ver reforma");
        Console.WriteLine("4. Total de reformas cerradas");
        Console.WriteLine("5. Salir");
        op = (opciones)Convert.ToInt32(Console.ReadLine());

        return op;
    }

    static void NuevaReforma(List<Reforma> reformas)
    {
        string dni;
        string nombre;
        DateTime fechaInicio;
        DateTime fechaPrevista;
        float precio;

        Console.WriteLine("Introduce dni");
        dni = Console.ReadLine();

        Reforma reforma = BuscarReforma(reformas,dni);

        if (reforma != null)
        {
            Console.WriteLine("Este cliente ya tiene una reforma registrada");
        }
        else
        {
            Console.WriteLine("Nombre: ");
            nombre = Console.ReadLine();
            Console.WriteLine("Fecha inicio: ");
            ValidarFecha(out fechaInicio);
            Console.WriteLine("Fecha prevista de fin");
            ValidarFecha(out fechaPrevista);
            Console.WriteLine("Precio: ");
            precio = Convert.ToSingle(Console.ReadLine());

            reformas.Add(new Reforma(dni, nombre, fechaInicio, fechaPrevista,
                precio));
        }
    }

    static void CerrarReforma(List<Reforma> reformas)
    {

        string dni;
        if (reformas.Count == 0)
        {
           Console.WriteLine("No hay reformas registradas.");
        }
        else
        {
            Console.WriteLine("Introduce el DNI del cliente:");
            dni = Console.ReadLine();

            Reforma reforma = BuscarReforma(reformas, dni);

            if (reforma == null)
            {
                Console.WriteLine("Reforma no encontrada.");
            }
            else if (reforma.Terminada)
            {
                Console.WriteLine("Esta reforma ya ha sido cerrada.");
            }
            else
            {
                Console.WriteLine("Introduce la fecha real de fin :");
                DateTime fechaReal;
                ValidarFecha(out fechaReal);

                reforma.FechaReal = fechaReal;
                reforma.Terminada = true;

                if (fechaReal > reforma.FechaPrevista)
                {
                    int diasRetraso = (fechaReal - reforma.FechaPrevista).Days;
                    float descuento = diasRetraso * 100;
                    reforma.Precio = Math.Max(0, reforma.Precio - descuento);
                }

                Console.WriteLine("Reforma cerrada correctamente.");
            }
        }
    }

    static void VerReforma(List<Reforma> reformas)
    {
        string dni;

        if(reformas.Count == 0)
        {
            Console.WriteLine("No hay reformas registradas.");
        }
        else
        {
            Console.WriteLine("Introduce el DNI de la reforma a consultar:");
            dni = Console.ReadLine();


            Reforma reforma = BuscarReforma(reformas, dni);

            if (reforma == null)
            {
                Console.WriteLine("Reforma no encontrada.");
            }
            else
            {
                Console.WriteLine("Detalles de la reforma:");
                Console.WriteLine(reforma.ToString());
            }
        }
    }

    static void TotalReformas(List<Reforma> reformas)
    {

        float total;
       
        total = reformas.Where(r => r.Terminada)
                            .Sum(r => r.Precio);

        if (total == 0)
        {
            Console.WriteLine("0€");
        }
        else
        {
            Console.WriteLine(total);
        }
        
    }

    static Reforma BuscarReforma(List<Reforma> reformas, string dni)
    {
        return reformas.FirstOrDefault(r => r.DNI == dni);
    }

    static bool ValidarFecha(out DateTime fecha)
    {
        string fechaInput;
        bool fechaCorrecta = false;
        fecha = DateTime.MinValue;

        while (!fechaCorrecta)
        {
            Console.WriteLine("Formato dd/MM/yyyy: ");
            fechaInput = Console.ReadLine();

            try
            {
                fecha = DateTime.ParseExact(fechaInput, "dd/MM/yyyy", null);
                fechaCorrecta = true;
            }
            catch (FormatException)
            {
                Console.WriteLine("Formato de fecha incorrecto.");
            }
        }

        return fechaCorrecta;
    }
}
