﻿/*clase donde se almacena toda la información de la reforma*/

class Reforma
{
    private string dni;
    private string nombre;
    private DateTime fechaInicio;
    private DateTime fechaPrevista;
    private float precio;
    private DateTime fechaReal;
    private bool terminada;

    public Reforma(string dni, string nombre, DateTime fechaInicio,
        DateTime fechaPrevista, float precio)
    {
        this.dni = dni;
        this.nombre = nombre;
        this.fechaInicio = fechaInicio;
        this.fechaPrevista = fechaPrevista;
        this.precio = precio;
        fechaReal = fechaPrevista;
        terminada = false;
    }

    public string DNI
    {
        get { return dni; }
        set { dni = value; }
    }

    public string Nombre
    {
        get { return nombre; }
        set { nombre = value; }
    }
    public DateTime FechaInicio
    {
        get { return fechaInicio; }
        set { fechaInicio = value; }
    }

    public DateTime FechaPrevista
    {
        get { return fechaPrevista; }
        set { fechaPrevista = value; }
    }

    public float Precio
    {
        get { return precio; }
        set { precio = value; }
    }

    public DateTime FechaReal
    {
        get { return fechaReal; }
        set { fechaReal = value; }
    }

    public bool Terminada
    {
        get { return terminada; }
        set { terminada = value; }
    }

    public override string ToString()
    {
        return "DNI: " + dni + "; Cliente: " + nombre +
           "; Inicio: " + fechaInicio.ToString("dd/MM/yyyy") +
           "; Prevista fin: " + fechaPrevista.ToString("dd/MM/yyyy") +
           "; Precio: " + precio + "€" +
           "; Real fin: " + fechaReal.ToString("dd/MM/yyyy") +
           "; Terminada: " + terminada;
    }
}
