﻿/*
 * CLase para definir las etapas de ciclismo, cuenta con un
 * array de ciclistas, podio
 */
using System.Text.RegularExpressions;

class Etapa
{
    protected string fecha;
    protected Ciclista[] podio;

    public Etapa(string fecha)
    {
        this.fecha = fecha;
        this.podio = new Ciclista[3];
    }

    public string GetFecha()
    {
        return fecha;
    }
    public void SetFecha(string fecha)
    {
        this.fecha = fecha;
    }

    public Ciclista[] GetPodio()
    { 
        return podio;
    }
    public void SetPodio(Ciclista[] podio)
    {
        this.podio = podio;
    }

    public bool ComprobarPodio(Ciclista cic)
    {
        bool existe = false;

        for (int i = 0; i < podio.Length; i++)
        {
            if (cic == podio[i])
            {
                existe = true;
            }
        }

        return existe;
    }

    public void MeterCiclista(Ciclista cic, int posicion)
    {
        podio[posicion] = cic;
    }

    public Ciclista MostrarGanador()
    {
        return podio[0];
    }

    public override string ToString()
    {
        return fecha + "\n" + "\t" + podio[0] + "\n" + "\t" + podio[1] + "\n" 
            + "\t" + podio[2];
    }
}
