﻿/*
 * Clase ciclista, define los ciclistas que participan
 * en las etapas
 */
class Ciclista
{
    protected int dorsal;
    protected string nombre;
    protected string equipo;

    public Ciclista(int dorsal, string nombre, string equipo)
    {
        SetDorsal(dorsal);
        SetNombre(nombre);
        SetEquipo(equipo);
    }

    public int GetDorsal() 
    { 
        return dorsal; 
    }
    public void SetDorsal(int dorsal)
    {
        this.dorsal = dorsal;
    }

    public string GetNombre()
    {
        return nombre;
    }
    public void SetNombre(string nombre)
    {
        this.nombre = nombre;
    }

    public string GetEquipo()
    {
        return equipo;
    }
    public void SetEquipo(string equipo)
    { 
        this.equipo = equipo;
    }

    public override string ToString()
    {
        return nombre + " - Nº" + dorsal + " - " + equipo;
    }
}
