﻿/*
 * Programa que pide al usuario los datos de Etapas y en caso de ser correctos
 * muestra un listado de las etapas ordenadas por su clave(fecha) y el podio
 * y un listado de los ciclistas que han ganado alguna etapa si repetirse
 */

using System;
using System.Collections;
using System.Collections.Generic;

class Principal
{
    static void ListaCiclistas(List<Ciclista> ciclistas)
    {
        for (int i = 0; i < ciclistas.Count; i++) 
            Console.WriteLine((i+1) + ". " + ciclistas[i]);
    }
    static List<Ciclista> CrearCiclistas()
    {
        List<Ciclista> ciclistas = new List<Ciclista>();

        ciclistas.Add(new Ciclista(235, "Miguel Indurain", 
            "AG2R CITROEN TEAM (FRA)"));
        ciclistas.Add(new Ciclista(101, "Eddy Merckx", 
            "MOVISTAR TEAM (ESP)"));
        ciclistas.Add(new Ciclista(128, "Bernard Hinault", 
            "TEAM DSM (PBA)"));
        ciclistas.Add(new Ciclista(455, "Jacques Anquetil", 
            "UAE TEAM EMIRATES (EAU)"));
        ciclistas.Add(new Ciclista(223, "Alberto Contador", 
            "BORA-HANSGROHE (ALE)"));
        ciclistas.Add(new Ciclista(675, "Chris Froome", 
            "ASTANA QAZAQSTAN TEAM (KAZ)"));

        return ciclistas;
    }

    static void CrearEtapa(SortedDictionary<string, Etapa> etapas,
        List<Ciclista> ciclistas, string fecha)
    {
        Etapa etapa;
        int numCiclista;

        Console.WriteLine();

        etapa = new Etapa(fecha);

        ListaCiclistas(ciclistas);
        Console.WriteLine();

        int posicion = 0;
        do
        {
            do
            {
                Console.Write("Posición " + (posicion + 1) + ": ");
            }
            while (!Int32.TryParse(Console.ReadLine(),
                out numCiclista) || numCiclista > ciclistas.Count ||
                etapa.ComprobarPodio(ciclistas[numCiclista - 1]) == true);

            etapa.MeterCiclista(ciclistas[numCiclista - 1], posicion);

            posicion++;
        }
        while (posicion < 3);

        // Se añade objeto al diccionario
        etapas.Add(fecha, etapa);
    }

    static void NuevaEtapa(SortedDictionary<string, Etapa> etapas, 
        List<Ciclista> ciclistas)
    {
        string fecha;

        do
        {
            Console.Write("Fecha etapa: ");
            fecha = Console.ReadLine();

            if (ValidarFecha(fecha)
                && !etapas.ContainsKey(fecha))
            {
                CrearEtapa(etapas, ciclistas, fecha);
            }
            else if (etapas.ContainsKey(fecha))
            {
                Console.WriteLine("Fecha ya existente");
            }
            else if (fecha != "")
            {
                Console.WriteLine("Fecha incorrecta");
            }
            Console.WriteLine();
        } 
        while (fecha != "");
    }

    static bool ValidarFecha(string fecha)
    {
        bool resultado = fecha.Length == 10;
        if(resultado)
        {
            for(int i = 0; i < fecha.Length; i++)
            {
                if(((i == 4 || i == 7) && fecha[i] != '-') ||
                    (i != 4 && i != 7 && (fecha[i] < '0' || fecha[i] > '9')))
                {
                    resultado = false;
                }
            }
        }
        return resultado;
    }

    static void ListaEtapas(SortedDictionary<string, Etapa> etapas)
    {
        Console.WriteLine("---| ETAPAS |---");
        IDictionaryEnumerator enumerador = etapas.GetEnumerator();
        while (enumerador.MoveNext())
        {
            Console.WriteLine(((Etapa)enumerador.Value));
        }
        Console.WriteLine();
    }

    static void ListaGanadores(SortedDictionary<string, Etapa> etapas)
    {
        HashSet<Ciclista> ganadores = new HashSet<Ciclista>();

        IDictionaryEnumerator enumerador = etapas.GetEnumerator();
        while (enumerador.MoveNext())
        {
            ganadores.Add(((Etapa)enumerador.Value).MostrarGanador());
        }

        Console.WriteLine("---| CICLISTAS GANADORES |---");
        foreach (Ciclista g in ganadores)
        {
            Console.WriteLine(g);
        }
        Console.WriteLine();
    }

    static void Main()
    {
        List<Ciclista> ciclistas = CrearCiclistas();
        SortedDictionary<string, Etapa> etapas = new 
            SortedDictionary<string, Etapa>();

        NuevaEtapa(etapas, ciclistas);

        ListaEtapas(etapas);

        ListaGanadores(etapas);
    }
}
