﻿/* La clase JuegoMesa tendrá los atributos y funcionalidad para gestionar
 * los juegos de mesa de la aplicación: nombre del juego, 
 * el precio, el tipo, la edad mínima para jugar, el número mínimo de 
 * jugadores y el número máximo.*/
class JuegoMesa
{
    public enum tipoJuego { ROL = 1, INFANTIL, AZAR, PUZZLE, OTROS }

    private string nombre;
    private float precio;
    private tipoJuego tipo;
    private int minEdad;
    private int minJugadores;
    private int maxJugadores;

    public JuegoMesa(string nombre, float precio, tipoJuego tipo, int minEdad, 
        int minJugadores, int maxJugadores)
    {
        Nombre = nombre;
        Precio = precio;
        Tipo = tipo;
        MinEdad = minEdad;
        MinJugadores = minJugadores;
        MaxJugadores = maxJugadores;
    }

    public string Nombre
    {
        get
        {
            return nombre;
        }
        set
        {
            nombre = value;
        }
    }

    public float Precio
    {
        get
        {
            return precio;
        }
        set
        {
            if (value < 0)
            {
                precio = 1;
            }
            else
            {
                precio = value;
            }
        }
    }
    public tipoJuego Tipo
    {
        get
        {
            return tipo;
        }
        set
        {
            if (value < tipoJuego.ROL || value > tipoJuego.PUZZLE)
            {
                tipo = tipoJuego.OTROS;
            }
            else
            {
                tipo = value;
            }
        }
    }

    public int MinEdad
    {
        get
        {
            return minEdad;
        }
        set
        {
            if (value < 1)
            {
                minEdad = 0;
            }
            else
            {
                minEdad = value;
            }
        }
    }

    public int MinJugadores
    {
        get
        {
            return minJugadores;
        }
        set
        {
            if (value < 1)
            {
                minJugadores = 0;
            }
            else
            {
                minJugadores = value;
            }
        }
    }

    public int MaxJugadores
    {
        get
        {
            return maxJugadores;
        }
        set
        {
            if (value < 1)
            {
                maxJugadores = 0;
            }
            else
            {
                maxJugadores = value;
            }
        }
    }

    public void Mostrar()
    {
        Console.WriteLine(nombre + " (" + tipo + "): " + precio+" euros, min "
            + minEdad + " años, Jugadores " + minJugadores+"-"+maxJugadores);
    }
}
