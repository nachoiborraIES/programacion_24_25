﻿/*
 * Personal administrativo que atiende las solicitudes
 */
class Administrativo
{
    public const string FICHERO = "administrativos.txt";

    private string dni;
    private string nombre;
    private string telefono;

    public string Dni
    {
        get { return dni; }
        set { dni = value; }
    }

    public string Nombre
    {
        get { return nombre; }
        set { nombre = value; }
    }

    public string Telefono
    {
        get { return telefono; }
        set { telefono = value; }
    }

    public Administrativo(string dni, string nombre, string telefono)
    {
        this.Dni = dni;
        this.Nombre = nombre;
        this.Telefono = telefono;
    }

    public override string ToString()
    {
        return dni  + ": " + nombre + ", " + telefono;
    }

    public string AFichero()
    {
        return dni + ";" + nombre + ";" + telefono;
    }

    public static List<Administrativo> CargarAdministrativos()
    {
        string linea;
        List<Administrativo> administrativos = new List<Administrativo>();

        if (File.Exists(FICHERO))
        {
            using (StreamReader fichero = new StreamReader(FICHERO))
            {
                while ((linea = fichero.ReadLine()) != null)
                {
                    string[] partes = linea.Split(';');
                    administrativos.Add(new Administrativo(partes[0], 
                        partes[1], partes[2]));
                    
                }
            }
        }

        return administrativos;
    }

    // Devuelve el administrativo con el DNI indicado, o null si no existe
    // Antigua función ComprobarAdmin que había en el programa principal,
    // modificada para que no lance excepciones
    public static Administrativo ComprobarAdmin(
        List<Administrativo> administrativos, string dni)
    {
        Administrativo resultado = null;

        foreach (Administrativo a in administrativos)
        {
            if (a.Dni == dni)
                resultado = a;
        }

        return resultado;
    }
}