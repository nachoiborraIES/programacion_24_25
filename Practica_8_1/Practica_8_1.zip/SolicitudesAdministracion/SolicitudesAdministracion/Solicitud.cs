﻿/*
 * Clase padre de todos los tipos de solicitudes
 */


using System.Diagnostics.Contracts;

class Solicitud
{
    public const string FICHERO = "solicitudes.txt";

    protected string id;
    protected string fecha;
    protected Administrativo administrativo;

    public string Id
    {
        get { return id; }
        set { id = value; }
    }

    public string Fecha
    {
        get { return fecha; }
        set { fecha = value; }
    }

    public Administrativo Administrativo
    {
        get { return administrativo; }
        set { administrativo = value; }
    }

    public Solicitud(string id, string fecha, Administrativo administrativo)
    {
        this.Id = id;
        this.Fecha = fecha;
        this.Administrativo = administrativo;
    }

    public override string ToString()
    {
        return "ID " + id + ". Realizada el " + fecha + ". ";
    }

    public virtual string AFichero()
    {
        return id + ";" + fecha + ";" + administrativo.Dni;
    }

    public static List<Solicitud> CargarSolicitudes(List<Administrativo> 
        administrativos)
    {
        string linea;
        List<Solicitud> solicitudes = new List<Solicitud>();

        if (File.Exists(FICHERO))
        {
            using (StreamReader fichero = new StreamReader(FICHERO))
            {
                while ((linea = fichero.ReadLine()) != null)
                {
                    string[] datos = linea.Split(';');

                    Administrativo admin = Administrativo.ComprobarAdmin(
                        administrativos, datos[3]);

                    if (admin != null)
                    {
                        switch (datos[0])
                        {
                            case "D":
                                solicitudes.Add(new SolicitudDomiciliacion(
                                    datos[1], datos[2], admin, datos[4]));
                                break;

                            case "T":
                                solicitudes.Add(new SolicitudTasas(datos[1],
                                    datos[2], admin, datos[4],
                                    Convert.ToSingle(datos[5])));
                                break;

                            case "R":
                                solicitudes.Add(new SolicitudReserva(datos[1],
                                    datos[2], admin, datos[4], datos[5], 
                                    datos[6], Convert.ToInt32(datos[7])));
                                break;
                        }
                    }
                }
            }
        }

        return solicitudes;
    }


    public static void GuardarSolicitudes(List<Solicitud> solicitudes)
    {
        try
        {
            using (StreamWriter fichero = new StreamWriter(FICHERO))
            {
                foreach (Solicitud s in solicitudes)
                {
                    fichero.WriteLine(s.AFichero());
                }
            }
        }
        catch (Exception e)
        {
            Console.WriteLine("Error escribiendo datos: {0}", e.Message);
        }
    }
}