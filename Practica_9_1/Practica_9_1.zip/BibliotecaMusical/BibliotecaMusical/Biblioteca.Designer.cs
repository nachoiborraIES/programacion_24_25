﻿namespace BibliotecaMusical
{
    partial class Biblioteca
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listCanciones = new ListBox();
            txtTitulo = new TextBox();
            label1 = new Label();
            label2 = new Label();
            txtMinutos = new TextBox();
            label3 = new Label();
            txtSegundos = new TextBox();
            cmbAutor = new ComboBox();
            label4 = new Label();
            btn_Anyadir = new Button();
            groupBox1 = new GroupBox();
            btnBorrar = new Button();
            btn_Aplicar = new Button();
            label6 = new Label();
            txtMinutosFiltro = new TextBox();
            cmbAutorFiltro = new ComboBox();
            label5 = new Label();
            label7 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // listCanciones
            // 
            listCanciones.FormattingEnabled = true;
            listCanciones.ItemHeight = 15;
            listCanciones.Location = new Point(10, 9);
            listCanciones.Margin = new Padding(3, 2, 3, 2);
            listCanciones.Name = "listCanciones";
            listCanciones.Size = new Size(270, 304);
            listCanciones.TabIndex = 0;
            // 
            // txtTitulo
            // 
            txtTitulo.Location = new Point(374, 46);
            txtTitulo.Margin = new Padding(3, 2, 3, 2);
            txtTitulo.Name = "txtTitulo";
            txtTitulo.Size = new Size(316, 23);
            txtTitulo.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(305, 48);
            label1.Name = "label1";
            label1.Size = new Size(43, 15);
            label1.TabIndex = 2;
            label1.Text = "Título: ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(305, 76);
            label2.Name = "label2";
            label2.Size = new Size(54, 15);
            label2.TabIndex = 4;
            label2.Text = "Minutos:";
            // 
            // txtMinutos
            // 
            txtMinutos.Location = new Point(374, 74);
            txtMinutos.Margin = new Padding(3, 2, 3, 2);
            txtMinutos.Name = "txtMinutos";
            txtMinutos.Size = new Size(100, 23);
            txtMinutos.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(506, 76);
            label3.Name = "label3";
            label3.Size = new Size(65, 15);
            label3.TabIndex = 6;
            label3.Text = "Segundos: ";
            // 
            // txtSegundos
            // 
            txtSegundos.Location = new Point(590, 74);
            txtSegundos.Margin = new Padding(3, 2, 3, 2);
            txtSegundos.Name = "txtSegundos";
            txtSegundos.Size = new Size(100, 23);
            txtSegundos.TabIndex = 5;
            // 
            // cmbAutor
            // 
            cmbAutor.FormattingEnabled = true;
            cmbAutor.Location = new Point(374, 102);
            cmbAutor.Margin = new Padding(3, 2, 3, 2);
            cmbAutor.Name = "cmbAutor";
            cmbAutor.Size = new Size(316, 23);
            cmbAutor.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(305, 104);
            label4.Name = "label4";
            label4.Size = new Size(40, 15);
            label4.TabIndex = 8;
            label4.Text = "Autor:";
            // 
            // btn_Anyadir
            // 
            btn_Anyadir.Location = new Point(459, 136);
            btn_Anyadir.Margin = new Padding(3, 2, 3, 2);
            btn_Anyadir.Name = "btn_Anyadir";
            btn_Anyadir.Size = new Size(144, 22);
            btn_Anyadir.TabIndex = 9;
            btn_Anyadir.Text = "Añadir";
            btn_Anyadir.UseVisualStyleBackColor = true;
            btn_Anyadir.Click += btn_Anyadir_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnBorrar);
            groupBox1.Controls.Add(btn_Aplicar);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(txtMinutosFiltro);
            groupBox1.Controls.Add(cmbAutorFiltro);
            groupBox1.Controls.Add(label5);
            groupBox1.Location = new Point(305, 182);
            groupBox1.Margin = new Padding(3, 2, 3, 2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 2, 3, 2);
            groupBox1.Size = new Size(384, 124);
            groupBox1.TabIndex = 10;
            groupBox1.TabStop = false;
            groupBox1.Text = "Filtrado de canciones";
            // 
            // btnBorrar
            // 
            btnBorrar.Location = new Point(224, 89);
            btnBorrar.Margin = new Padding(3, 2, 3, 2);
            btnBorrar.Name = "btnBorrar";
            btnBorrar.Size = new Size(144, 22);
            btnBorrar.TabIndex = 13;
            btnBorrar.Text = "Borrar Filtros";
            btnBorrar.UseVisualStyleBackColor = true;
            btnBorrar.Click += btnBorrar_Click;
            // 
            // btn_Aplicar
            // 
            btn_Aplicar.Location = new Point(24, 89);
            btn_Aplicar.Margin = new Padding(3, 2, 3, 2);
            btn_Aplicar.Name = "btn_Aplicar";
            btn_Aplicar.Size = new Size(144, 22);
            btn_Aplicar.TabIndex = 11;
            btn_Aplicar.Text = "Aplicar Filtros";
            btn_Aplicar.UseVisualStyleBackColor = true;
            btn_Aplicar.Click += btn_Aplicar_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(19, 56);
            label6.Name = "label6";
            label6.Size = new Size(40, 15);
            label6.TabIndex = 12;
            label6.Text = "Autor:";
            // 
            // txtMinutosFiltro
            // 
            txtMinutosFiltro.Location = new Point(200, 23);
            txtMinutosFiltro.Margin = new Padding(3, 2, 3, 2);
            txtMinutosFiltro.Name = "txtMinutosFiltro";
            txtMinutosFiltro.Size = new Size(168, 23);
            txtMinutosFiltro.TabIndex = 1;
            // 
            // cmbAutorFiltro
            // 
            cmbAutorFiltro.FormattingEnabled = true;
            cmbAutorFiltro.Location = new Point(68, 56);
            cmbAutorFiltro.Margin = new Padding(3, 2, 3, 2);
            cmbAutorFiltro.Name = "cmbAutorFiltro";
            cmbAutorFiltro.Size = new Size(300, 23);
            cmbAutorFiltro.TabIndex = 11;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(19, 26);
            label5.Name = "label5";
            label5.Size = new Size(159, 15);
            label5.TabIndex = 0;
            label5.Text = "Duración máxima (minutos):";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(465, 21);
            label7.Name = "label7";
            label7.Size = new Size(104, 15);
            label7.TabIndex = 11;
            label7.Text = "Nuevas Canciones";
            // 
            // Biblioteca
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(700, 338);
            Controls.Add(label7);
            Controls.Add(groupBox1);
            Controls.Add(btn_Anyadir);
            Controls.Add(label4);
            Controls.Add(cmbAutor);
            Controls.Add(label3);
            Controls.Add(txtSegundos);
            Controls.Add(label2);
            Controls.Add(txtMinutos);
            Controls.Add(label1);
            Controls.Add(txtTitulo);
            Controls.Add(listCanciones);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 2, 3, 2);
            MaximizeBox = false;
            Name = "Biblioteca";
            StartPosition = FormStartPosition.CenterScreen;
            Text = " Biblioteca Musical";
            FormClosed += Biblioteca_FormClosed;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listCanciones;
        private TextBox txtTitulo;
        private Label label1;
        private Label label2;
        private TextBox txtMinutos;
        private Label label3;
        private TextBox txtSegundos;
        private ComboBox cmbAutor;
        private Label label4;
        private Button btn_Anyadir;
        private GroupBox groupBox1;
        private Label label5;
        private Button btnBorrar;
        private Button btn_Aplicar;
        private Label label6;
        private TextBox txtMinutosFiltro;
        private ComboBox cmbAutorFiltro;
        private Label label7;
    }
}
