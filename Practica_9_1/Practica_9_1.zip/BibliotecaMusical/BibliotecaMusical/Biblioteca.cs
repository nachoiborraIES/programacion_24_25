// Ventana principal del programa donde haremos todas las interacciones
namespace BibliotecaMusical
{
    public partial class Biblioteca : Form
    {
        private List<Cancion> canciones;
        private List<Autor> autores;

        public Biblioteca()
        {
            InitializeComponent();

            autores = Autor.CargarAutores();
            canciones = Cancion.CargarCanciones();
            MostrarCanciones(canciones);
            
            foreach (Autor a in autores)
            {
                cmbAutor.Items.Add(a);
                cmbAutorFiltro.Items.Add(a);
            }
        }

        private void MostrarCanciones(List<Cancion> canciones)
        {
            listCanciones.Items.Clear();
            foreach (Cancion c in canciones)
            {
                listCanciones.Items.Add(c);
            }
        }

        private void btn_Anyadir_Click(object sender, EventArgs e)
        {
            if (txtMinutos.Text != "" && txtSegundos.Text != "" && 
                txtTitulo.Text != "" && cmbAutor.SelectedItem != null)
            {
                string titulo = txtTitulo.Text;
                int minutos = Convert.ToInt32(txtMinutos.Text);
                int segundos = Convert.ToInt32(txtSegundos.Text);
                Autor autor = (Autor)cmbAutor.SelectedItem;
                Cancion nueva = new Cancion(titulo, minutos, segundos, autor);
                canciones.Add(nueva);
                MostrarCanciones(canciones);

                txtMinutos.Clear();
                txtSegundos.Clear();
                txtTitulo.Clear();
                cmbAutor.SelectedIndex = -1;
            }
            else
                MessageBox.Show("No puedes dejar campos vacios");

        }

        private void btn_Aplicar_Click(object sender, EventArgs e)
        {
            List<Cancion> filtradas = new List<Cancion>();
            bool correcta;
            Autor autorElegido;


            foreach (Cancion c in canciones)
            {
                correcta = true;
                if (txtMinutosFiltro.Text != "")
                {
                    if (c.Minutos >= Convert.ToInt32(txtMinutosFiltro.Text))
                        correcta = false;
                }
                if (cmbAutorFiltro.SelectedItem != null)
                {
                    autorElegido = (Autor)cmbAutorFiltro.SelectedItem;
                    if (!autorElegido.Equals(c.Autor))
                        correcta = false;
                }
                if (correcta)
                    filtradas.Add(c);
            }

            MostrarCanciones(filtradas);
        }

        private void Biblioteca_FormClosed(object sender, FormClosedEventArgs e)
        {
            Cancion.GuardarCanciones(canciones);
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            txtMinutosFiltro.Clear();
            cmbAutorFiltro.SelectedItem = null;
            MostrarCanciones(canciones);
        }
    }
}
