﻿//Clase Autor donde guardamos toda la información de ellos
namespace BibliotecaMusical
{
    internal class Autor
    {
        const string FICHERO = "autores.txt";

        protected string nombre;
        protected bool grupo;

        public Autor(string nombre, bool grupo)
        {
            this.nombre = nombre;
            this.grupo = grupo;
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public bool Grupo
        {
            get { return grupo; }
            set { grupo = value; }
        }

        public override bool Equals(object? obj)
        {
            return obj is Autor autor &&
                   nombre == autor.nombre;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(nombre);
        }

        public static List<Autor> CargarAutores()
        {
            List<Autor> autores = new List<Autor>();
            string nombre, linea;
            bool grupo;

            if(File.Exists(FICHERO))
            {
                using(StreamReader fichero = new StreamReader(FICHERO))
                {
                    while ((linea = fichero.ReadLine()) != null)
                    {
                        string[] partes = linea.Split(';');
                        if(partes.Length == 2)
                        {
                            nombre = partes[0];
                            if (partes[1] == "0")
                                grupo = false;
                            else
                                grupo = true;
                            autores.Add(new Autor(nombre, grupo));
                        }
                    }
                }
            }
            return autores;
        }

        public override string ToString()
        {
            return nombre;
        }
    }
}
