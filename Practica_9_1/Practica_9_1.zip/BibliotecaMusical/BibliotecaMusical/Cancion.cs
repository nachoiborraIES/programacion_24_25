﻿using System.Text.Json;

//Clase Canción donde guardamos toda la información sobre ella y serializamos
namespace BibliotecaMusical
{
    internal class Cancion
    {
        const string FICHEROCANCIONES = "canciones.json";

        protected string titulo;
        protected int minutos;
        protected int segundos;
        protected Autor autor;

        public Cancion(string titulo, int minutos, int segundos,
            Autor autor)
        {
            this.titulo = titulo;
            Minutos = minutos;
            Segundos = segundos;
            this.autor = autor;
        }

        public string Titulo
        {
            get { return titulo; }
            set { titulo = value; }
        }

        public int Minutos
        {
            get { return minutos; }
            set
            {
                if (value < 0)
                {
                    minutos = 0;
                }
                else
                {
                    minutos = value;
                }
            }
        }

        public int Segundos
        {
            get { return segundos; }
            set
            {
                if (value < 0)
                {
                    segundos = 0;
                }
                else if (value > 59)
                {
                    segundos = 59;
                }
                else
                {
                    segundos = value;
                }
            }
        }

        public Autor Autor
        {
            get { return autor; }
            set { autor = value; }
        }

        public static List<Cancion> CargarCanciones()
        {
            List<Cancion> listadoCanciones = new List<Cancion>();
            if (File.Exists(FICHEROCANCIONES))
            {
                string jsonString2;
                jsonString2 = File.ReadAllText(FICHEROCANCIONES);
                listadoCanciones =
                    JsonSerializer.Deserialize<List<Cancion>>(jsonString2);
            }
            return listadoCanciones;
        }

        public static void GuardarCanciones(List<Cancion> cancions)
        {
            string jsonString;
            var opciones = new JsonSerializerOptions { WriteIndented = true };
            jsonString = JsonSerializer.Serialize(cancions, opciones);
            File.WriteAllText(FICHEROCANCIONES, jsonString);
        }

        public override string ToString()
        {
            return "[" + autor + "] " + titulo + " (" + minutos + ":" +
                segundos + ")";
        }
    }
}
