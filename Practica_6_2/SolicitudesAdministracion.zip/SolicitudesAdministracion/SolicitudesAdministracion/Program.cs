﻿/*
 * Programa principal de gestión de solicitudes
 */

enum opciones { SALIR, NUEVA, ADMINISTRATIVO, LISTADO, TOTAL }

class Program
{
    // Comprueba si el id ya existe en el array o no. Lanza excepción si existe
    static void ComprobarId(Solicitud[] solicitudes, int cantidad, string id)
    {
        for (int i = 0; i < cantidad; i++)
        {
            if (solicitudes[i].Id == id)
                throw new Exception("El Id de solicitud ya existe");
        }
    }

    // Devuelve el administrativo con el DNI indicado,
    // o lanza excepción si no está
    static Administrativo ComprobarAdmin(Administrativo[] administrativos,
        string dni)
    {
        Administrativo resultado = null;

        foreach(Administrativo a in administrativos)
        {
            if (a.Dni == dni)
                resultado = a;
        }

        if (resultado == null)
            throw new Exception("No se ha encontrado un administrativo con " +
                "el DNI indicado");
        return resultado;
    }

    // Comprueba si el número de cuenta es correcto o no (lanza excepción)
    static void ComprobarNumCuenta(string cuenta)
    {
        if (cuenta.Length != 20)
            throw new Exception("Número de cuenta incorrecto");
        else
        {
            foreach (char digito in cuenta)
            {
                if (digito < '0' || digito > '9')
                    throw new Exception("Número de cuenta incorrecto");
            }
        }
    }

    // Resto de funciones para las opciones del programa principal

    static Administrativo[] RellenarAdministrativos()
    {
        Administrativo[] administrativos = new Administrativo[4];
        administrativos[0] = new Administrativo("11223344A", "Juan Pérez",
            "611223344");
        administrativos[1] = new Administrativo("44332211B", "Elisa López",
            "644332211");
        administrativos[2] = new Administrativo("55667788C", "Raquel Sánchez",
            "655667788");
        administrativos[3] = new Administrativo("88776655D", "Sergio Zamora",
            "688776655");

        return administrativos;
    }

    static void ListarAdministrativos(Administrativo[] administrativos)
    {
        Console.WriteLine("Listado de administrativos:");
        foreach (Administrativo a in administrativos)
            Console.WriteLine(a);
    }

    static opciones Menu()
    {
        opciones opcion;
        Console.Clear();
        Console.WriteLine("{0}. Nueva solicitud", (int)opciones.NUEVA);
        Console.WriteLine("{0}. Solicitudes por administrativo", 
            (int)opciones.ADMINISTRATIVO);
        Console.WriteLine("{0}. Listado de solicitudes", (int)opciones.LISTADO);
        Console.WriteLine("{0}. Total pendiente de pago", (int)opciones.TOTAL);
        Console.WriteLine("{0}. Salir", (int)opciones.SALIR);
        Console.Write("Elige una opción: ");
        opcion = (opciones)Convert.ToInt32(Console.ReadLine());
        return opcion;
    }

    static void NuevaSolicitud(Solicitud[] solicitudes, ref int cantidad,
        Administrativo[] administrativos)
    {
        Solicitud nueva;
        Administrativo admin;
        int tipo, horas;
        float importe;
        string id, fecha, dni, cuenta, concepto, espacio, fechaReserva, horaInicio;

        Console.WriteLine("Elige tipo de solicitud:");
        Console.WriteLine("1. Domiciliación / 2. Tasas / 3. Reserva");
        tipo = Convert.ToInt32(Console.ReadLine());

        // Pedimos datos comunes

        Console.Write("Id. de solicitud: ");
        id = Console.ReadLine();
        ComprobarId(solicitudes, cantidad, id);

        Console.Write("Fecha solicitud: ");
        fecha = Console.ReadLine();

        ListarAdministrativos(administrativos);
        Console.Write("DNI administrativo: ");
        dni = Console.ReadLine();
        admin = ComprobarAdmin(administrativos, dni);

        // Distinguimos tipo de solicitud
        if (tipo == 1)
        {
            Console.Write("Núm. cuenta: ");
            cuenta = Console.ReadLine();
            ComprobarNumCuenta(cuenta);

            solicitudes[cantidad] = new SolicitudDomiciliacion(id, fecha,
                admin, cuenta);
            cantidad++;
        }
        else if (tipo == 2)
        {
            Console.Write("Concepto: ");
            concepto = Console.ReadLine();

            Console.Write("Importe a pagar: ");
            if (!Single.TryParse(Console.ReadLine(), out importe) || importe <= 0)
                throw new Exception("Importe incorrecto");
            solicitudes[cantidad] = new SolicitudTasas(id, fecha, admin,
                concepto, importe);
            cantidad++;
        }
        else
        {
            Console.Write("Espacio: ");
            espacio = Console.ReadLine();
            Console.Write("Fecha reserva: ");
            fechaReserva = Console.ReadLine();
            Console.Write("Hora inicio reserva: ");
            horaInicio = Console.ReadLine();
            Console.Write("Duración reserva (horas): ");
            horas = Convert.ToInt32(Console.ReadLine());
            solicitudes[cantidad] = new SolicitudReserva(id, fecha, admin,
                espacio, fechaReserva, horaInicio, horas);
            cantidad++;
        }
    }

    static void SolicitudesPorAdmin(Solicitud[] solicitudes, int cantidad,
        Administrativo[] administrativos)
    {
        string dni;
        bool resultados = false;

        ListarAdministrativos(administrativos);
        Console.Write("DNI administrativo: ");
        dni = Console.ReadLine();
        ComprobarAdmin(administrativos, dni);

        for(int i = 0; i < cantidad; i++)
        {
            if (solicitudes[i].Administrativo.Dni == dni)
            {
                resultados = true;
                Console.WriteLine(solicitudes[i]);
            }
        }

        if (!resultados)
            Console.WriteLine("El administrativo seleccionado no tiene " +
                "solicitudes a su cargo");
    }

    static void ListadoSolicitudes(Solicitud[] solicitudes, int cantidad)
    {
        for(int i = 0; i < cantidad; i++)
        {
            if (solicitudes[i] is SolicitudDomiciliacion)
                Console.ForegroundColor = ConsoleColor.Blue;
            else if (solicitudes[i] is SolicitudTasas)
                Console.ForegroundColor = ConsoleColor.Red;
            else
                Console.ForegroundColor = ConsoleColor.Green;

            Console.WriteLine(solicitudes[i]);
        }

        Console.ResetColor();
    }

    static void TotalPagar(Solicitud[] solicitudes, int cantidad)
    {
        float total = 0;

        for(int i = 0; i < cantidad; i++)
        {
            if (solicitudes[i] is SolicitudTasas)
            {
                total += ((SolicitudTasas)solicitudes[i]).Importe;
            }
        }

        Console.WriteLine("Total a pagar: {0} eur.", total.ToString("N2"));
    }

    static void Main()
    {
        Administrativo[] administrativos = RellenarAdministrativos();
        Solicitud[] solicitudes = new Solicitud[20];
        int cantidad = 0;
        opciones opcion;

        do
        {
            opcion = Menu();
            switch (opcion)
            {
                case opciones.NUEVA:
                    try
                    {
                        NuevaSolicitud(solicitudes, ref cantidad, administrativos);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Error: " + e.Message);
                    }
                    break;
                case opciones.ADMINISTRATIVO:
                    try
                    {
                        SolicitudesPorAdmin(solicitudes, cantidad, administrativos);
                    }
                    catch(Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    break;
                case opciones.LISTADO:
                    ListadoSolicitudes(solicitudes, cantidad);
                    break;
                case opciones.TOTAL:
                    TotalPagar(solicitudes, cantidad);
                    break;
            }

            Console.WriteLine("Pulsa cualquier tecla para continuar...");
            Console.ReadKey(true);
        }
        while (opcion != opciones.SALIR);
    }
}